package App;

import BD.BoiteBD;
import BD.ContenirbBD;
import BD.ContenirfBD;
import BD.ContenirpBD;
import BD.Contenu;
import UI.Exception.BoiteExistanteException;

import java.util.List;
import java.util.UUID;
import java.util.ArrayList;

/**
 * Service de gestion des boîtes LEGO.
 */
public class BoiteService {
    private final BoiteBD boiteBD;
    private final Contenu contenuBD;
    private final ContenirpBD contenirpBD;
    private final ContenirfBD contenirfBD;
    private final ContenirbBD contenirbBD;
    private final ThemeService themeService;

    /**
     * Crée un service de gestion des boîtes.
     *
     * @param boiteBD l'accès aux données des boîtes
     * @param contenuBD l'accès aux données des contenus
     * @param contenirpBD l'accès aux associations pièce-contenu
     * @param contenirfBD l'accès aux associations figurine-contenu
     * @param contenirbBD l'accès aux associations boîte-contenu
     * @param themeService le service des thèmes
     */
    public BoiteService(BoiteBD boiteBD, Contenu contenuBD, ContenirpBD contenirpBD, ContenirfBD contenirfBD, ContenirbBD contenirbBD, ThemeService themeService) {
        this.boiteBD = boiteBD;
        this.contenuBD = contenuBD;
        this.contenirpBD = contenirpBD;
        this.contenirfBD = contenirfBD;
        this.contenirbBD = contenirbBD;
        this.themeService = themeService;
    }

    /**
     * Ajoute une nouvelle boîte en base de données.
     *
     * @param boite la boîte à ajouter
     * @throws BoiteExistanteException si une boîte avec le même numéro existe déjà
     */
    public void ajouterBoite(Boite boite) throws BoiteExistanteException {
        if (rechercherBoiteParNumero(boite.getNumero()) != null) {
            throw new BoiteExistanteException("Une boîte avec le numéro " + boite.getNumero() + " existe déjà.");
        }
        boiteBD.insererBoite(boite);
    }

    /**
     * Liste toutes les boîtes.
     *
     * @return la liste des boîtes
     */
    public List<Boite> listerBoites() {
        return boiteBD.listeDesBoites();
    }

    /**
     * Recherche une boîte par son numéro.
     *
     * @param numero le numéro de la boîte
     * @return la boîte ou null si non trouvée
     */
    public Boite rechercherBoiteParNumero(String numero) {
        return boiteBD.rechercherBoite(numero);
    }

    /**
     * Recherche les boîtes d'un thème, incluant les sous-thèmes.
     *
     * @param theme le thème recherché
     * @return la liste des boîtes du thème et ses sous-thèmes
     */
    public List<Boite> rechercherBoitesParTheme(Theme theme) {
        List<Boite> resultat = new ArrayList<>();
        if (theme == null) return resultat;

        resultat.addAll(boiteBD.listeBoitesParTheme(theme.getIdTheme()));

        List<Theme> sousThemes = themeService.listerSousThemes(theme.getIdTheme());

        for (Theme sousTheme : sousThemes) {
            resultat.addAll(rechercherBoitesParTheme(sousTheme));
        }

        return resultat;
    }

    /**
     * Crée une boîte personnalisée avec les pièces spécifiées.
     *
     * @param nom le nom de la boîte
     * @param themePersonnalise le thème de la boîte
     * @param pieces la liste des pièces à inclure
     * @param forcerCreation true pour ignorer les vérifications de doublons
     * @return la boîte créée
     * @throws BoiteIdentiqueException si une boîte identique existe et forcerCreation est false
     */
    public Boite composerBoitePersonnalisee(String nom, Theme themePersonnalise, List<PieceQuantite> pieces, boolean forcerCreation) throws BoiteIdentiqueException {
        if (!forcerCreation && boiteIdentiqueExiste(pieces)) {
            throw new BoiteIdentiqueException("Une boîte contenant exactement ces pièces existe déjà.");
        }

        String numeroUnique = "PERSO-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();

        Boite nouvelleBoite = new Boite(numeroUnique, nom, 2026, themePersonnalise, null);
        nouvelleBoite.setPersonnalisee(true);
        for (PieceQuantite pq : pieces) {
            nouvelleBoite.ajouterPiece(pq);
        }
        
        boiteBD.insererBoite(nouvelleBoite);
        
        return nouvelleBoite;
    }

    /**
     * Charge une boîte complète avec tout son contenu (pièces, figurines, boîtes incluses).
     *
     * @param numero le numéro de la boîte
     * @return la boîte avec son contenu complet, ou null si non trouvée
     */
    public Boite chargerBoiteComplete(String numero) {
        Boite b = boiteBD.rechercherBoite(numero);
        if (b == null) return null;

        List<Contenu.ContenuDetail> listContenus = contenuBD.listeContenusParBoite(numero);
        for (Contenu.ContenuDetail c : listContenus) {
            int idContenu = c.getIdCont();

            List<PieceQuantite> pieces = contenirpBD.listeContenirpParContenu(idContenu);
            for (PieceQuantite pq : pieces) {
                b.ajouterPiece(pq);
            }

            List<App.FigurineQuantite> figurines = contenirfBD.listeContenirfParContenu(idContenu);
            for (App.FigurineQuantite fq : figurines) {
                b.ajouterFigurine(fq);
            }
            
            List<App.BoiteQuantite> sousBoites = contenirbBD.listeContenirbParContenu(idContenu);
            for (App.BoiteQuantite bq : sousBoites) {
                b.ajouterBoiteIncluse(bq);
            }
        }
        return b;
    }

    /**
     * Calcule les statistiques d'une boîte.
     *
     * @param numero le numéro de la boîte
     * @return les statistiques de la boîte ou null si non trouvée
     */
    public App.BoiteStats calculerStatsBoite(String numero) {
        Boite b = chargerBoiteComplete(numero);
        if (b == null) return null;

        int totalPieces = 0;
        int totalSupplements = 0;
        int totalFigurines = 0;
        int totalSousBoites = 0;
        java.util.Map<App.Couleur, Integer> repartitionCouleurs = new java.util.LinkedHashMap<>();

        for (PieceQuantite pq : b.getPieces()) {
            totalPieces += pq.getQuantite();
            if (pq.isEnSupplement()) {
                totalSupplements += pq.getQuantite();
            }
            App.Couleur c = pq.getPiece().getCouleur();
            if (c != null) {
                repartitionCouleurs.put(c, repartitionCouleurs.getOrDefault(c, 0) + pq.getQuantite());
            }
        }

        for (App.FigurineQuantite fq : b.getFigurines()) {
            totalFigurines += fq.getQuantite();
        }

        for (App.BoiteQuantite bq : b.getBoitesIncluses()) {
            totalSousBoites += bq.getQuantite();
        }

        return new App.BoiteStats(totalPieces, totalSupplements, totalFigurines, totalSousBoites, repartitionCouleurs);
    }

    /**
     * Vérifie si une boîte identique (même contenu de pièces) existe.
     *
     * @param pieces la liste des pièces
     * @return true si une boîte identique existe
     */
    private boolean boiteIdentiqueExiste(List<PieceQuantite> pieces) {
        return false; 
    }

    /**
     * Recherche les boîtes par nom.
     *
     * @param nom le nom recherché
     * @return la liste des boîtes correspondantes
     */
    public List<Boite> rechercherBoitesParNom(String nom) {
        return boiteBD.rechercherBoitesParNom(nom);
    }

    /**
     * Recherche les boîtes contenant une pièce donnée.
     *
     * @param numPiece le numéro de la pièce
     * @return la liste des boîtes contenant cette pièce
     */
    public List<Boite> rechercherBoitesParPiece(String numPiece) {
        return boiteBD.rechercherBoitesParPiece(numPiece);
    }

    /**
     * Ajoute une pièce à une boîte.
     *
     * @param numBoite le numéro de la boîte
     * @param pq la pièce à ajouter
     * @return true si l'ajout a réussi, false sinon
     */
    public boolean ajouterPieceABoite(String numBoite, PieceQuantite pq) {
        List<Contenu.ContenuDetail> contenus = contenuBD.listeContenusParBoite(numBoite);
        
        if (contenus.isEmpty()) {
            return false;
        }
        
        int idCont = contenus.get(0).getIdCont();

        return contenirpBD.insererContenirp(idCont, pq) > 0;
    }

    /**
     * Récupère une portion restreinte de boîtes (Pagination).
     *
     * @param page numéro de la page active
     * @param taillePage nombre maximum de résultats par page
     * @return la liste paginée des boîtes
     */
    public List<Boite> listerBoitesPaginees(int page, int taillePage) {
        int offset = (page - 1) * taillePage;
        return boiteBD.listeDesBoitesPaginee(taillePage, offset);
    }

    /**
     * Compte le nombre total de boîtes dans la base de données.
     *
     * @return le nombre de boîtes total
     */
    public int obtenirNombreTotalBoites() {
        return boiteBD.compterBoites();
    }

    /**
     * Liste un sous-ensemble de boîtes selon des critères de recherche et pagination.
     *
     * @param recherche le nom partiel à rechercher
     * @param idTheme l'identifiant du thème
     * @param page numéro de la page active
     * @param taillePage nombre d'éléments maximum par page
     * @return la liste filtrée et paginée
     */
    public List<Boite> listerBoitesFiltreesPaginees(String recherche, Integer idTheme, int page, int taillePage) {
        int offset = (page - 1) * taillePage;
        return boiteBD.rechercherBoitesFiltreesPaginees(recherche, idTheme, taillePage, offset);
    }

    /**
     * Retourne le nombre total de boîtes correspondant aux critères.
     *
     * @param recherche le nom partiel à rechercher
     * @param idTheme l'identifiant du thème
     * @return le total de résultats filtrés
     */
    public int obtenirNombreTotalBoitesFiltrees(String recherche, Integer idTheme) {
        return boiteBD.compterBoitesFiltrees(recherche, idTheme);
    }
}